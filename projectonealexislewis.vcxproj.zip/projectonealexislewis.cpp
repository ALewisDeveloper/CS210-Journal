//Alexis Lewis

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;
//Declaring variables
int hours = 0;
int minutes = 0;
int seconds = 0;

//Function decelerations (prototypes)
void AddHours(int i);                      //Ensures hours value does not exceed 24
void AddMinutes(int i);                    //Ensures minutes value does not exceed 60
void AddSeconds(int i);                    //Ensures seconds value does not exceed 60 
void ClearScreen();                        //Prints 4 blank lines 
string WriteLines(char character, int times);  //Returns string: a line
void PrintTop_ButtomLine();                //Prints the 1st and 4th line in the DisplayTime() function.
void PrintSecondLine();                     //Prints the 2nd line in the DisplayTime() function output.
void PrintThirdLine();                      //Prints the 3rd and 4th line in the DisplayTime() function output.
void DisplayTime();                         //Prints the time in the correct formats
void DisplayMenu();                         //Prints the formatted menu to the user
int GetInput(string question);               //Returns an integer response to aquestion as argument

int main() {
	bool pressButton;
	while (true) {
		ClearScreen();
		DisplayTime();
		pressButton = (GetInput("Press button? (1 - Yes, 2 - No) ") == 2);
		if (pressButton) {
			AddSeconds(1);
			continue; //While loop restarts
		}
		else {
			DisplayMenu();
			int userInput = GetInput("Enter Menu Selection: ");
			if (userInput == 4) {
				break; //While loop ends. Program exits.
			}
			else if (userInput == 1) {
				//AddHours(GetInput("Enter count: ")); //Adds customizable number of hours user enters
				AddHours(1); //Adds 1 hour
			}
			else if (userInput == 2) {
				//AddMinutes(GetInput("Enter count: "));
				AddMinutes(1); //Adds 1 minute
			}
			else if (userInput == 3) {
				//AddSeconds(GetInput("Enter count: "));
				AddSeconds(1); //Adds 1 second
			}
		}

	}
	return 0;
}

void ClearScreen() {
	for (int i = 0; i < 4; i++) {
		cout << endl;
	}
}

void DisplayTime() {
	PrintTop_ButtomLine();
	PrintSecondLine();
	PrintThirdLine();
	PrintTop_ButtomLine();
}

void PrintTop_ButtomLine() {
	string text;
	text = WriteLines('*', 57);   //assigns text with a string: 57 asterisks
	text.replace(27, 5, "     ");     //Starting at index 27 in text, replaces the next 5 chars with 5 spaces
	cout << text << endl;
}

void PrintSecondLine() {
	string text;
	text = WriteLines(' ', 57);
	text.at(0) = '*'; //Replaces char at starting index with an asterisk
	text.at(26) = '*';
	text.at(32) = '*';
	text.at(56) = '*';
	text.replace(7, 13, "12 Hour Clock");
	text.replace(39, 13, "24 Hour Clock");
	cout << text << endl;
}

void PrintThirdLine() {
	string text;
	string iosTime; //Stores time in 12-hour format
	string stdTime; //Stores time in 24-hour format
	text = WriteLines(' ', 57);
	text.at(0) = '*';
	text.at(26) = '*';
	text.at(32) = '*';
	text.at(56) = '*';
	string meridiem; //Stores meridiem
	int hour;
	if (hours < 12) {          //This IF formats the 12-hour time system 
		meridiem = " AM";   //If time is before 12:0:0, AM is appended for 12-hour format
		hour = hours;
	}
	else {                     //If time is after 12:0:0,
		meridiem = " PM";   //PM is appended for 12-hour format
		if (hours == 12) {
			hour = 12;
		}
		else {                      //If hour is 13 or less than 24
			hour = hours - 12;  //hour is truncated
		}
	}

	iosTime = to_string(hour) + ':' + to_string(minutes) + ':' + to_string(seconds) + meridiem;
	stdTime = to_string(hours) + ':' + to_string(minutes) + ':' + to_string(seconds);

	text.replace(9, iosTime.length(), iosTime);
	text.replace(43, stdTime.length(), stdTime);

	cout << text << endl;
}

string WriteLines(char character, int times) {
	string text = "";
	for (int i = 0; i < times; i++) {
		text += character;
	}
	return text;
}

void AddHours(int i) {
	hours += i;
	if (hours > 23) {
		hours = 0;
	}
}

void AddMinutes(int i) {
	minutes += i;
	if (minutes > 59) {
		AddHours(minutes / 60);
		minutes %= 60;
	}
}

void AddSeconds(int i) {
	seconds += i;
	if (seconds > 59) {
		AddMinutes(seconds / 60);
		seconds %= 60;
	}
}

int GetInput(string question) {
	int input;
	cout << question << flush;
	cin >> input;
	return input;
}

void DisplayMenu() {
	cout << WriteLines('*', 27) << endl;
	cout << "* 1-Add One Hour          *" << endl;
	cout << "* 2-Add One Minute        *" << endl;
	cout << "* 3-Add One Second        *" << endl;
	cout << "* 4-Exit Program          *" << endl;
	cout << WriteLines('*', 27) << endl;
}